# Calculadora simple

def sumar(n1, n2):
    return n1 + n2

def restar(n1, n2):
    return n1 - n2

def multiplicar(n1, n2):
    return n1 * n2

def dividir(n1, n2):
    return n1 / n2

print("Operaciones")
print("1.Sumar")
print("2.Restar")
print("3.Multiplicar")
print("4.Dividir")

while True:
    # Toma la opcion ingresada
    opcion = input("Seleccionar opcion(1/2/3/4): ")

    # Verificar opcion
    if opcion in ('1', '2', '3', '4'):
        num1 = float(input("Primer numero: "))
        num2 = float(input("Segundo numero: "))

        if opcion == '1':
            print(num1, "+", num2, "=", sumar(num1, num2))

        elif opcion == '2':
            print(num1, "-", num2, "=", restar(num1, num2))

        elif opcion == '3':
            print(num1, "*", num2, "=", multiplicar(num1, num2))

        elif opcion == '4':
            print(num1, "/", num2, "=", dividir(num1, num2))
        break
    else:
        print("Opcion invalida")