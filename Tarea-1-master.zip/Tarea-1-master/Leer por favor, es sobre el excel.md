# Tarea-1
Tuve que convertir el excel a pdf, ya que no tengo
la licencia de office y tuve que hacerlo un mi
celular, y a veces los archivos que creo en el
celular no se abren en pc, por eso.
